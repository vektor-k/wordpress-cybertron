<?php

add_action('init','of_options');

if (!function_exists('of_options')) {
function of_options(){
	
// VARIABLES
$themename = get_theme_data(STYLESHEETPATH . '/style.css');
$themename = $themename['Name'];
$shortname = "tgpwp";

// Populate OptionsFramework option in array for use in theme
global $of_options;
$of_options = get_option('of_options');

$GLOBALS['template_path'] = OF_DIRECTORY;

//Access the WordPress Categories via an Array
$of_categories = array();  
$of_categories_obj = get_categories('hide_empty=0');
foreach ($of_categories_obj as $of_cat) {
    $of_categories[$of_cat->cat_ID] = $of_cat->cat_name;}
$categories_tmp = array_unshift($of_categories, "Select a category:");    
       
//Access the WordPress Pages via an Array
$of_pages = array();
$of_pages_obj = get_pages('sort_column=post_parent,menu_order');    
foreach ($of_pages_obj as $of_page) {
    $of_pages[$of_page->ID] = $of_page->post_name; }
$of_pages_tmp = array_unshift($of_pages, "Select a page:");       

// Image Alignment radio box
$options_thumb_align = array("alignleft" => "Left","alignright" => "Right","aligncenter" => "Center"); 

// Image Links to Options
$options_image_link_to = array("image" => "The Image","post" => "The Post"); 

//Testing 
$options_select = array("one","two","three","four","five"); 
$options_radio = array("one" => "One","two" => "Two","three" => "Three","four" => "Four","five" => "Five"); 

//Stylesheets Reader
$alt_stylesheet_path = OF_FILEPATH . '/styles/';
$alt_stylesheets = array();

if ( is_dir($alt_stylesheet_path) ) {
    if ($alt_stylesheet_dir = opendir($alt_stylesheet_path) ) { 
        while ( ($alt_stylesheet_file = readdir($alt_stylesheet_dir)) !== false ) {
            if(stristr($alt_stylesheet_file, ".css") !== false) {
                $alt_stylesheets[] = $alt_stylesheet_file;
            }
        }    
    }
}

//More Options
$uploads_arr = wp_upload_dir();
$all_uploads_path = $uploads_arr['path'];
$all_uploads = get_option('of_uploads');
$other_entries = array("Select a number:","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");
$body_repeat = array("no-repeat","repeat-x","repeat-y","repeat");
$body_pos = array("top left","top center","top right","center left","center center","center right","bottom left","bottom center","bottom right");
$imagepath =  get_bloginfo('stylesheet_directory') . '/admin/images/';

// Set the Options Array
$options = array();

$options[] = array( "name" => "General Settings",
                    "type" => "heading");
                    
$options[] = array( "name" => "Color Scheme",
					"desc" => "Choose the color scheme you want to use on the site. You have three options, want more? Then hire me for a custom design!",
					"id" => $shortname."_color_scheme",
					"std" => "Select One",
					"type" => "select",
					"options" => array("brown","red","purple", "pink"));
					
$options[] = array( "name" => "Header Background",
						"desc" => "Enter a color you want for the header background.",
						"id" => $shortname."_header_bg",
						"std" => "#000000",
						"type" => "color");					
				
$options[] = array( "name" => "Custom Logo",
					"desc" => "Upload a logo for your theme, or specify the image address of your online logo. (http://yoursite.com/logo.png)",
					"id" => $shortname."_logo",
					"std" => "",
					"type" => "upload"); 

$options[] = array( "name" => "Logo Padding",
					"desc" => "Enter the padding you want for the logo. Must be numbers only coded like example. This way you can center logo or text in the space. (eg: 40px 0 0 35px)",
					"id" => $shortname."_logo_padding",
					"std" => "53px 0 0 37px",
					"type" => "text");
										
$options[] = array( "name" => "Custom Favicon",
					"desc" => "Upload a 16px x 16px Png/Gif image that will represent your website's favicon.",
					"id" => $shortname."_custom_favicon",
					"std" => "",
					"type" => "upload");
					 
$options[] = array( "name" => "Gallery Topper",
					"desc" => "Enter the text you want for the topper above the images on the index page.",
					"id" => $shortname."_gallery_topper",
					"std" => "",
					"type" => "text");
					
$options[] = array( "name" => "Featured Gallery Topper",
					"desc" => "Enter the text you want for the featured topper above the images on the index page.",
					"id" => $shortname."_featured_topper",
					"std" => "",
					"type" => "text");
					                                              
$options[] = array( "name" => "Tracking Code",
					"desc" => "Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme.",
					"id" => $shortname."_google_analytics",
					"std" => "",
					"type" => "textarea");

$options[] = array( "name" => "Enable Thumbnail Titles",
					"desc" => "Check to enable post titles above the thumbnails on the index page.",
					"id" => $shortname."_thumbnail_title",
					"std" => "false",
					"type" => "checkbox");					
					
$options[] = array( "name" => "Disable Featured Galleries",
					"desc" => "Check to disable the featured gallery section. Only standard post/galleries will show up on the index pages.",
					"id" => $shortname."_disable_featgally",
					"std" => "true",
					"type" => "checkbox");
					
$options[] = array( "name" => "Disable Comments",
					"desc" => "Check to disable comments on all post, pages do not have a comment section at all. This will override WordPress settings and not show comments at all.",
					"id" => $shortname."_disable_comments",
					"std" => "true",
					"type" => "checkbox");				
						
$options[] = array( "name" => "Advertising",
					"type" => "heading");
					
$options[] = array( "name" => "Header Banner Padding",
					"desc" => "Enter the padding you want for the header banner. Must be numbers only coded like example. This way you can center banner or text in the space. (eg: 40px 0 0 35px)",
					"id" => $shortname."_banner_padding",
					"std" => "21px 0 0 0",
					"type" => "text");
										
$options[] = array( "name" => "Header Banner",
					"desc" => "Enter the code for the banner in the header. Max size is 500x100px. Any bigger and bad things happen. Be sure to use the padding setting above to center the banner.",
					"id" => $shortname."_header_ad",
					"std" => "",
					"type" => "textarea");
					
$options[] = array( "name" => "WordPress Loop Ad",
					"desc" => "Enter the code for the advertising you want to place inside the WordPress loop. It is set to show after every 6 post",
					"id" => $shortname."_loopad",
					"std" => "",
					"type" => "textarea");

$options[] = array( "name" => "Search Page",
					"desc" => "Enter the code for the advertising you want on the search results page.",
					"id" => $shortname."_search_ad",
					"std" => "",
					"type" => "textarea");				
					
$options[] = array( "name" => "Archive Page",
					"desc" => "Enter the code for the advertising you want on all archive pages.",
					"id" => $shortname."_archive_ad",
					"std" => "",
					"type" => "textarea");

$options[] = array( "name" => "404 page",
					"desc" => "Enter the code for the advertising you want on the 404 page.",
					"id" => $shortname."_404_ad",
					"std" => "",
					"type" => "textarea");
					
$options[] = array( "name" => "Pages",
					"desc" => "Enter the code for the advertising you want on all pages.",
					"id" => $shortname."_pages_ad",
					"std" => "",
					"type" => "textarea");									

update_option('of_template',$options); 					  
update_option('of_themename',$themename);   
update_option('of_shortname',$shortname);

}
}
?>
