<?php
/**TGP WP V2.8**/
get_header();
?>
		<!-- content -->	
		<div id="page-content">
		<h3>That page or post is no longer here!</h3>
			<h2 class="nopost">Ever Feel Like You're Not Supposed to Be Here?<br>Well what ever you're looking for it's gone, but you can go<br>back to the <a href="<?php echo get_option('home'); ?>/">Homepage Here</a>!</h2>
			<!-- banner -->
		<div class="archive-banner" align="center">
				<?php if(get_option('tgpwp_404_ad')) { ?>
				<?php echo get_option('tgpwp_404_ad'); ?>
				<?php } else { ?>
				<a href="http://tgpwp.com"><img src="<?php bloginfo('template_url'); ?>/images/gallery-banner.gif" alt="Get this WordPress theme for free here!" /></a>
				<?php } ?>
		</div><!-- /banner -->
		</div><!-- /content -->
<?php get_sidebar(); ?>
</div><!-- /content area -->
<?php include (TEMPLATEPATH . '/includes/single-footer-widget.php'); ?>
<?php get_footer(); ?>