<?php
/**TGP WP V2.8**/
?>
<!-- footer -->
<div id="footer">
		<div class="footer-menu">
		<?php wp_nav_menu( array( 'container' => false, 'theme_location' => 'footer-menu' ) ); ?>
	</div>

<!-- If you want to remove the link to my site then please donate to my coffee fund. It's what keeps me going! -->
<p class="copyrights">&copy; Copyright <a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a> | Theme by <a href="http://tgpwp.com" title="Free Wordpress Theme">www.TGPWP.com</a></p>

</div><!-- /footer -->
<?php wp_footer(); ?>
<?php $google_analytics = get_option('tgpwp_google_analytics'); if ($google_analytics) { echo stripslashes($google_analytics); } ?>
</div>
<!-- /wrapper -->

</body>
</html>