<?php
/**TGP WP V2.5**/

get_header();
?>
		<!-- Archive Content -->	
		<div id="archive-content">
			<h3>Here is what we found for your search</h3>
			<?php if (have_posts()) : ?>
			<div id="photo-layout">
			<?php while (have_posts()) : the_post(); ?>
				<!-- post -->
				<div class="home-post-wrap">
					<div class="thumbnail-div">
				<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php if ( has_post_thumbnail() ) { the_post_thumbnail( 'thumb' );
} else { ?>
<img src="<?php bloginfo('template_directory'); ?>/images/temp-image.jpg" alt="<?php the_title(); ?>" />
<?php } ?></a>
				</div>
				<div class="infobox">
				<div class="ratingbox"><!-- ratingbox -->
				<?php if(function_exists('the_ratings')) { the_ratings(); } ?>
			</div><!-- /ratingbox -->
			<div class="viewbox">
			<?php if(function_exists('the_views')) {  ?><p class="views"><?php the_views(); ?></p><?php } ?>
			</div>
		</div>
				</div><!-- /post -->
			<?php endwhile; ?>
			</div>
			<?php 
			$next_page = get_next_posts_link('Previous'); 
			$prev_pages = get_previous_posts_link('Next');
			if(!empty($next_page) || !empty($prev_pages)) :
			?>
			<!-- navigation -->
			<div class="navigation">
				<?php if(!function_exists('wp_pagenavi')) : ?>
				<div class="alignleft"><?php echo $next_page; ?></div>
				<div class="alignright"><?php echo $prev_pages; ?></div>
				<?php else : wp_pagenavi(); endif; ?>
			</div>
			<!-- /navigation -->
			<?php endif; ?>
			
				<?php else : ?>
				<h2 class="nopost">Sorry, We didn't find anything on here like that<br>Try another search or check out the banner below!</h2>
				<?php	endif; ?>
		<div class="clear"></div>
		<!-- banner -->
		<div class="archive-banner" align="center">
				<?php if(get_option('tgpwp_search_ad')) { ?>
				<?php echo get_option('tgpwp_search_ad'); ?>
				<?php } else { ?>
				<a href="http://tgpwp.com"><img src="<?php bloginfo('template_url'); ?>/images/gallery-banner.gif" alt="Get this WordPress theme for free here!" /></a>
				<?php } ?>
		</div><!-- /banner -->
		</div><!-- /content -->
<?php get_sidebar(); ?>
</div><!-- /content area -->
<?php include (TEMPLATEPATH . '/includes/single-footer-widget.php'); ?>
<?php get_footer(); ?>