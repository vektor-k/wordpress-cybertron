<?php
/*TGPWP V2.5*/
/* This is for attachment images */
get_header();
?>
	<?php if (have_posts()) : ?>
			<?php while (have_posts()) : the_post(); ?>
			<?php $current_post_id = get_the_ID(); $post_cats = wp_get_post_categories( get_the_ID(), NULL ); sort($post_cats,SORT_NUMERIC); ?> 
					<div id="attachpic">
					<?php $et_event_settings = maybe_unserialize( get_post_meta($post->post_parent,'et_event_settings',true) ); ?>
					<!-- post -->
					<div <?php post_class('post') ?> id="post-<?php the_ID(); ?>">
						<h3><?php the_title(); ?></h3>
						<div class="entry" align="center">
						<!-- Single Text Code -->
								<div id="attachlink">
								<a href="<?php echo $et_event_settings['tlink']; ?>"><?php echo $et_event_settings['text']; ?></a>
								</div>
								<!-- /Single Text Code -->
						<img src="<?php echo $post->guid; ?>" alt="<?php the_title(); ?>" class="bigimage" title="<?php the_title(); ?>" <?php echo $image_info[3]; ?> />
						<div class="linkback"><a href="<?php echo get_permalink($post->post_parent); ?>">Back To The Gallery</a></div>
					</div>
					<!-- /post -->
			<?php endwhile; ?>
		<?php else: ?>
		<p class="nopost">Sorry, no posts matched your criteria.</p>
		<?php endif; ?>
	</div>
</div><!-- /attachpic -->
	</div><!-- /content_body -->
<?php include (TEMPLATEPATH . '/includes/single-footer-widget.php'); ?>
<?php get_footer(); ?>