<?php
/**TGPWP V2.8**/
 global $shortname, $css_style_path;
?>
<div class="rightside">
	<div id="sidebar">
		<!-- Search Box -->
		<div id="search-box">
			<form action="<?php bloginfo('url'); ?>/" method="get">
				<fieldset>
					<input type="text" value="Search..." name="s" id="search-input" onclick="this.value=''" onblur="if(this.value=='') this.value='Search...';" />
					<?php (get_option('tgpwp_color_scheme')); ?>
					<input type="image" src="<?php bloginfo('template_url'); ?>/themes/<?php echo get_option('tgpwp_color_scheme'); ?>/images/search-button.gif" alt="search" id="main_search_sub" />
				</fieldset>
			</form>
		</div>
		<!-- /Search Box -->
			<ul>
				<?php	if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Sidebar') ) : ?>
				
				<li class="sidebox">
					<h2 class="widget-title">Categories</h2>
					<ul id="widget_categories"><?php wp_list_categories('show_count=1&title_li='); ?></ul>
				</li>
				
				<li class="sidebox">
					<h2 class="widget-title">Sponsor Banner</h2>
					<div class="sideadwrap">
					<a href="http://tgpwp.com"><img src="<?php bloginfo('template_url'); ?>/images/sidebar-ad.jpg" alt="Get this theme free now!" /></a>
					</div>
				</li>
				
				<li class="sidebox">
					<h2 class="widget-title">Top Links</h2>
					<ul>
					<?php wp_list_bookmarks('title_li=&categorize=0'); ?>
					</ul>
				</li>
								
				<?php endif; ?>
			</ul>
	</div>
</div>