<?php
/**TGP WP V2.8**/
get_header();

$orderby = 'date';
$orderby = '&orderby=date';
if(isset($_GET['order']) && !empty($_GET['order']))
{
	$order = $_GET['order'];
	switch($order)
	{ 
		case 'rated' :	$orderby = '&r_sortby=highest_rated&r_orderby=desc';
			break;
		case 'viewed' :	$orderby = '&v_sortby=views&v_orderby=desc';
			break;
		default :	 $orderby = '&orderby=date';
			break;
	}
}
$order_url = get_option('home').'/?order=';
?>
		<!-- content_body -->
		<div id="content-body">
		<div class="gallery-title">
				<?php if(get_option('tgpwp_gallery_topper')) { ?>
				<h3><?php echo get_option('tgpwp_gallery_topper'); ?></h3>
				<?php } else { ?>
				<h3>Recently Added Cam Girls</h3>
				<?php } ?>
				<div class="orderby">
					<label>Let Me See:</label>
					<select onchange="location=this.options[this.selectedIndex].value">
						<option value="<?php echo $order_url; ?>date"<?php if($order=='date') : ?> selected="selected"<?php endif; ?>>Latest</option>
						<option value="<?php echo $order_url; ?>viewed"<?php if($order=='viewed') : ?> selected="selected"<?php endif; ?>>Most Viewed</option>
						<option value="<?php echo $order_url; ?>rated"<?php if($order=='rated') : ?> selected="selected"<?php endif; ?>>Top Rated</option>
					</select>
				</div><!-- orderby -->
			</div>
			<div id="photo-layout">
		<?php $i=0; query_posts($query_string.$orderby); if (have_posts()) : while (have_posts()) : the_post(); $i++; ?>
				<!-- post -->
				<div class="home-post-wrap">
					<?php if (get_option('tgpwp_thumbnail_title') == "true") { ?>
				<div class="posttitle"><a href="<?php the_permalink() ?>"><?php short_title('...', '20'); ?></a></div>
				<?php } ?>
					<div class="thumbnail-div">
						<?php if ( has_post_thumbnail() ) { ?>
						<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">
							<?php the_post_thumbnail( 'thumb' ); ?></a>
							<?php } else { ?>
							<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><img src="<?php bloginfo('template_directory'); ?>/images/temp-image.jpg" alt="<?php the_title(); ?>" /></a>
							<?php } ?>
				</div>
				<div class="infobox">
				<div class="ratingbox"><!-- ratingbox -->
				<?php if(function_exists('the_ratings')) { the_ratings(); } ?>
			</div><!-- /ratingbox -->
			<div class="viewbox">
			<?php if(function_exists('the_views')) {  ?><p class="views"><?php the_views(); ?></p><?php } ?>
			</div>
		</div>
				</div>
					<?php if($i%8==0) : ?><?php (get_option('tgpwp_loopad')); ?><div class="loopad" align="center"><?php echo get_option('tgpwp_loopad'); ?></div><?php endif; ?>
				<!-- /post -->
			<?php endwhile; ?>
			</div>
			<div class="clear"></div>
			<?php if (get_option('tgpwp_disable_featgally') == "false") { ?>
				<?php include (TEMPLATEPATH . '/featured.php'); ?>
				<?php } ?>
			<?php 
			$next_page = get_next_posts_link('Previous'); 
			$prev_pages = get_previous_posts_link('Next');
			if(!empty($next_page) || !empty($prev_pages)) :
			?>
			<!-- navigation -->
			<div class="navigation" align="center">
				<?php if(!function_exists('wp_pagenavi')) : ?>
				<div class="alignleft"><?php echo $next_page; ?></div>
				<div class="alignright"><?php echo $prev_pages; ?></div>
				<?php else : wp_pagenavi(); endif; ?>
			</div>
			<!-- /navigation -->
			<?php endif; ?>
					<?php else: ?><p class="nopost">Nothing Here, the webmaster has not added anything yet!</p><?php endif; ?>
		</div>
		<?php get_sidebar(); ?>
</div><!-- /content_body -->
</div><!-- /Content Area -->
<?php include (TEMPLATEPATH . '/includes/main-footer-widget.php'); ?>
<?php get_footer(); ?>