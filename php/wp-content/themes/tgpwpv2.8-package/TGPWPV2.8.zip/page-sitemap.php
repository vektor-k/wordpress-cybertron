<?php
/*TGP WP V2.5
Template Name: Sitemap
*/

get_header(); 
?>
		<!-- content -->	
		<div id="page-content">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<!-- post -->
			<div class="post page" id="post-<?php the_ID(); ?>">
				<h3><?php the_title(); ?></h3>
				<div class="page-entry">
					<?php the_content(); ?>
 				<h5>Pages</h5>
                            <ul><?php wp_list_pages("title_li=" ); ?></ul>
                        <h5>Feeds</h5>
                            <ul>
                                <li><a title="Full content" href="feed:<?php bloginfo('rss2_url'); ?>">Main RSS</a></li>
                                <li><a title="Comment Feed" href="feed:<?php bloginfo('comments_rss2_url'); ?>">Comment Feed</a></li>
                            </ul>
                        <h5>Categories</h5>
                            <ul><?php wp_list_cats('sort_column=name&optioncount=1&hierarchical=0&feed=RSS'); ?></ul>
                        <h5>All Blog Posts:</h5>
                            <ul><?php $archive_query = new WP_Query('showposts=1000&cat=-8');
                                    while ($archive_query->have_posts()) : $archive_query->the_post(); ?>
                                        <li>
                                            <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a>
                                         (<?php comments_number('0', '1', '%'); ?>)
                                        </li>
                                    <?php endwhile; ?>
                            </ul>

                        <h5>Archives</h5>
                            <ul>
                                <?php wp_get_archives('type=monthly&show_post_count=true'); ?>
                            </ul>			
				</div>
			</div>
			<!-- /post -->
			<?php endwhile; endif; ?>
		<div class="clear"></div>
		<!-- banner -->
		<div class="archive-banner" align="center">
							<?php if(get_option('tgpwp_page_ad')) { ?>
				<?php echo get_option('tgpwp_page_ad'); ?>
				<?php } else { ?>
				<a href="http://tgpwp.com"><img src="<?php bloginfo('template_url'); ?>/images/gallery-banner.gif" alt="Get this WordPress theme for free here!" /></a>
				<?php } ?>
		</div><!-- /banner -->
		</div><!-- /content -->
<?php get_sidebar(); ?>
</div><!-- /content area -->
<?php include (TEMPLATEPATH . '/includes/single-footer-widget.php'); ?>
<?php get_footer(); ?>