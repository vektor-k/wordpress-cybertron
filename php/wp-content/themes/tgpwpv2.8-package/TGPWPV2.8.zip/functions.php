<?php
//////////////////////////////////////////////////////////////////
// Options Framework Functions
//////////////////////////////////////////////////////////////////

/* Set the file path based on whether the Options Framework is in a parent theme or child theme */

if ( STYLESHEETPATH == TEMPLATEPATH ) {
	define('OF_FILEPATH', TEMPLATEPATH);
	define('OF_DIRECTORY', get_bloginfo('template_directory'));
} else {
	define('OF_FILEPATH', STYLESHEETPATH);
	define('OF_DIRECTORY', get_bloginfo('stylesheet_directory'));
}

/* These files build out the options interface.  Likely won't need to edit these. */

require_once (OF_FILEPATH . '/admin/admin-functions.php');		// Custom functions and plugins
require_once (OF_FILEPATH . '/admin/admin-interface.php');		// Admin Interfaces (options,framework, seo)

/* These files build out the theme specific options and associated functions. */

require_once (OF_FILEPATH . '/admin/theme-options.php'); 		// Options panel settings and custom settings
require_once (OF_FILEPATH . '/admin/theme-functions.php'); 	// Theme actions based on options settings

//////////////////////////////////////////////////////////////////
// Register sidebar and footer widgets
//////////////////////////////////////////////////////////////////
if ( function_exists('register_sidebar') ) {
	register_sidebar(array(
		'name' => 'Sidebar',
		'before_widget' => '<li id="%1$s" class="sidebox %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h2 class="widget-title">',
		'after_title' => '</h2>',
		'description' => 'Place widgets here to show up on the main sidebar',
	));
	register_sidebar(array(
		'name' => 'Gallery Footer',
		'before_widget' => '<li id="%1$s" class="widgetbox %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h2 class="widget-title">',
		'after_title' => '</h2>',
		'description' => 'Widgets here will only show up on the galleries.',
	));
	register_sidebar(array(
		'name' => 'Index Footer',
		'before_widget' => '<li id="%1$s" class="widgetbox %2$s">',
		'after_widget' => '</li>',
		'before_title' => '<h2 class="widget-title">',
		'after_title' => '</h2>',
		'description' => 'Widgets here will only show up on the index page.',
	));
}
//////////////////////////////////////////////////////////////////
// Include function files
//////////////////////////////////////////////////////////////////
include(TEMPLATEPATH . "/includes/footer-widget.php");
include(TEMPLATEPATH . "/includes/sidebar-widget.php");
include(TEMPLATEPATH . "/includes/recent-post-widget.php");
include(TEMPLATEPATH . "/includes/advert-functions.php");
include(TEMPLATEPATH . "/includes/meta-box.php");
//////////////////////////////////////////////////////////////////
// This removes the default gallery style by WordPress
//////////////////////////////////////////////////////////////////
add_filter( 'use_default_gallery_style', '__return_false' );
//////////////////////////////////////////////////////////////////
// Post thumbnails
//////////////////////////////////////////////////////////////////
if ( function_exists( 'add_theme_support' ) ) {
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 170, 210, true );
	add_image_size( 'mobile-thumb', 120, 140, true );
	add_image_size( 'recent-thumb', 65, 80, true );
	add_image_size( 'thumb', 170, 210, true );
}
//////////////////////////////////////////////////////////////////
// This will add a link to my site in the Admin Bar at the top
//////////////////////////////////////////////////////////////////
function wp_admin_bar_new_item() {
global $wp_admin_bar;
$wp_admin_bar->add_menu(array(
'id' => 'wp-admin-bar-new-item',
'title' => __('TGPWP Support'),
'href' => 'http://tgpwp.com'
));
}
add_action('wp_before_admin_bar_render', 'wp_admin_bar_new_item');
//////////////////////////////////////////////////////////////////
// This will let you style the Tags widget when activated
//////////////////////////////////////////////////////////////////
add_filter('widget_tag_cloud_args','style_tags');
function style_tags($args) {
$args = array(
     'largest'    => '13',
     'smallest'   => '13',
     'format'     => 'flat',
     'number'			=> '28',
     'orderby' => 'count',
     'order' => 'DESC'
     );
return $args;
}
//////////////////////////////////////////////////////////////////
// This is to get rid of the WP-PageNavi styling
//////////////////////////////////////////////////////////////////
add_action( 'wp_print_styles', 'my_deregister_styles', 100 );

function my_deregister_styles() {
	wp_deregister_style( 'wp-pagenavi' );
}
//////////////////////////////////////////////////////////////////
// This is for the WordPress Menu & Superfish Intergration
//////////////////////////////////////////////////////////////////
function add_wp3menu_support() {

register_nav_menus(
		array(
		'main-menu' => __('Header Navigation'),
		'footer-menu' => __( 'Footer Navigation' ),
				)
		 );
}

add_action('init', add_wp3menu_support);

function add_our_scripts() {

	if (!is_admin()) { // Add the scripts, but not to the wp-admin section.
	// /* Adjust the below path to where scripts dir is, if you must. */
	$scriptdir = get_bloginfo('template_url')."/java/";
	
	// /* Remove the wordpresss inbuilt jQuery. */
	wp_deregister_script('jquery');

	// /* Lets use the one from Google AJAX API instead. */
	wp_register_script( 'jquery', 'http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js', false, '1.4.2');

	// /* Register the Superfish javascript file */
	wp_register_script( 'superfish', $scriptdir.'sf/sf.js', false, '1.4.8');
	
	// /* load the scripts and style. */
	wp_enqueue_script('jquery');
	wp_enqueue_script('superfish');
	}
}

// Add our function to the wp_head. You can also use wp_print_scripts.
add_action( 'wp_head', 'add_our_scripts',0);
//////////////////////////////////////////////////////////////////
// This is for the Short Title
//////////////////////////////////////////////////////////////////
function short_title($after = '', $length) {
    $mytitle = get_the_title();
    if ( strlen($mytitle) > $length ) {
    $mytitle = substr($mytitle,0,$length);
    echo rtrim($mytitle).$after;
    } else {
    echo $mytitle;
    }
}
//////////////////////////////////////////////////////////////////
// This will add our Featured custom post type
//////////////////////////////////////////////////////////////////
add_action( 'init', 'create_post_types' );
function create_post_types() {
	register_post_type( 'Featured',
		array(
		  'labels' => array(
			'name' => __( 'Featured', 'tgpwp' ),
			'singular_name' => __( 'Featured', 'tgpwp' ),		
			'add_new' => _x( 'Add New', 'Featured Project', 'tgpwp' ),
			'add_new_item' => __( 'Add New Featured Project', 'tgpwp' ),
			'edit_item' => __( 'Edit Featured Project', 'tgpwp' ),
			'new_item' => __( 'New Featured Project', 'tgpwp' ),
			'view_item' => __( 'View Featured Project', 'tgpwp' ),
			'search_items' => __( 'Search Featured Projects', 'tgpwp' ),
			'not_found' =>  __( 'No Featured Projects found', 'tgpwp' ),
			'not_found_in_trash' => __( 'No Featured Projects found in Trash', 'tgpwp' ),
			'parent_item_colon' => ''
			
		  ),
		  'public' => true,
		  'supports' => array('title','editor','thumbnail'),
		  'query_var' => true,
		  'rewrite' => array( 'slug' => 'featured' ),
		)
	  );
}

// functions run on activation --> important flush to clear rewrites
if ( is_admin() && isset($_GET['activated'] ) && $pagenow == 'themes.php' ) {
	$wp_rewrite->flush_rules();
}

//////////////////////////////////////////////////////////////////
// This is going to add the custom background Wordpress feature
//////////////////////////////////////////////////////////////////
if ( function_exists('get_custom_header')) {
        add_theme_support('custom-background');
        } else {
        
        // Backward Compatibility
       add_custom_background();
        }
//////////////////////////////////////////////////////////////////
// This is to handel the new comments section on the pages
//////////////////////////////////////////////////////////////////
function thman_comment($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment; ?>
	<li <?php comment_class(); ?> id="comment-<?php comment_ID() ?>">
	
		<div class="the-comment">
		
			<?php echo get_avatar($comment,$size='60'); ?>
			
			<div class="comment-arrow"></div>
			
			<div class="comment-box">
			
				<div class="comment-author">
					<strong><?php echo get_comment_author_link() ?></strong>
					<small><?php printf(__('%1$s at %2$s'), get_comment_date(),  get_comment_time()) ?></a><?php edit_comment_link(__('Edit'),'  ','') ?> - <?php comment_reply_link(array_merge( $args, array('reply_text' => 'Reply', 'add_below' => $add_below, 'depth' => $depth, 'max_depth' => $args['max_depth']))) ?></small>
				</div>
			
				<div class="comment-text">
					<?php if ($comment->comment_approved == '0') : ?>
					<em><?php _e('Your comment is awaiting moderation.') ?></em>
					<br />
					<?php endif; ?>
					<?php comment_text() ?>
				</div>
			
			</div>
			
		</div>

<?php }
 ?>