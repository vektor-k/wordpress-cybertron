<?php
/**TGPWP V2.5**/
get_header();
?>
	<?php if (have_posts()) : ?>
			<?php while (have_posts()) : the_post(); ?>
			<?php $current_post_id = get_the_ID(); $post_cats = wp_get_post_categories( get_the_ID(), NULL ); sort($post_cats,SORT_NUMERIC); ?> 
					<div id="single-gallery">
					<!-- post -->
					<div <?php post_class('post') ?> id="post-<?php the_ID(); ?>">
						<h3><?php the_title(); ?></h3>
						<?php $et_event_settings = maybe_unserialize( get_post_meta($post->ID,'et_event_settings',true) ); ?>
						<!-- Single Text Code -->
								<div id="tlink">
								<a href="<?php echo $et_event_settings['tlink']; ?>"><?php echo $et_event_settings['text']; ?></a>
								</div><!-- /Single Text Code -->
						<div class="entry">
							<?php the_content('Read the rest of this entry &raquo;'); ?>
							<!-- Single Banner Code -->
								<div class="single-banner" align="center">
								<a href="<?php echo $et_event_settings['link']; ?>"><img src="<?php echo $et_event_settings['banner']; ?>" /></a>
								</div><!-- /Single Banner Code -->
						<div class="postmeta">
							<div class="tagbox">
								<?php the_tags('Search Tags: ', ', ', ''); ?><br />Added On: <?php the_date() ?></div>
								
									<div class="ratingbox-single"><?php if(function_exists('the_ratings')) { the_ratings(); } ?></div>
						<div class="clear"></div>
						</div>
					</div>
					<!-- /post -->
			<?php endwhile; ?>
	<!-- Related Photo Box -->
	<div class="related-box">
		<div class="related-box-title">
			<h2>Related Photo Galleries</h2>
			<?php if(isset($post_cats[0])) : ?><p><a href="<?php echo get_category_link( $post_cats[0] ); ?>">See More Related Galleries</a></p><?php endif; ?>
		</div>
		<!-- single_content -->
		<div class="related-content">
			<?php
			query_posts('showposts=10&orderby=rand&cat='.implode(',',$post_cats));
			if (have_posts()) : ?>
			<?php $i=0; while (have_posts()) : the_post(); if($current_post_id==get_the_ID()) continue; $i++; ?>
				<!-- post -->
				<div class="home-post-wrap">
					<div class="thumbnail-div">
					<?php if ( has_post_thumbnail() ) { ?>
						<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>">
							<?php the_post_thumbnail( 'thumb' ); ?></a>
							<?php } else { ?>
							<a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><img src="<?php bloginfo('template_directory'); ?>/images/temp-image.jpg" alt="<?php the_title(); ?>" /></a>
							<?php } ?>
				</div>
				<div class="infobox">
				<div class="ratingbox"><!-- ratingbox -->
				<?php if(function_exists('the_ratings')) { the_ratings(); } ?>
			</div><!-- /ratingbox -->
			<div class="viewbox">
			<?php if(function_exists('the_views')) {  ?><p class="views"><?php the_views(); ?></p><?php } ?>
			</div>
		</div>
				</div>
				<?php if($i%4==0) : ?><div class="clear"></div><?php endif; ?>
				<!-- /post -->
			<?php endwhile; ?>
			<?php else : ?>
			<p class="nopost">Sorry, but you are looking for something that isn't here.</p>
			<?php	endif; wp_reset_query(); ?>
	</div><!-- /related-content -->		
		</div><!-- /related-box -->
		<!-- /Related Photo Box -->
		<?php if (get_option('tgpwp_disable_comments') == "false") { ?>
				<?php comments_template(); ?>
				<?php } ?>
		<?php else: ?>
		<p class="nopost">Sorry, no posts matched your criteria.</p>
		<?php endif; ?>
	</div>
</div><!-- /single-gallery -->
	<?php get_sidebar(); ?>
	</div><!-- /content_body -->
<?php include (TEMPLATEPATH . '/includes/single-footer-widget.php'); ?>
<?php get_footer(); ?>