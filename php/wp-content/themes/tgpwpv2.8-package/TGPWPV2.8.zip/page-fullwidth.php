<?php
/*TGP WP V2.5
Template Name: Fullwidth
*/

get_header(); 
?>
		<!-- content -->	
		<div id="fullpage-content">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<!-- post -->
			<div id="post-<?php the_ID(); ?>">
				<h3><?php the_title(); ?></h3>
				<div class="page-entry">
					<?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?>
			</div>
			</div>
			<!-- /post -->
			<?php endwhile; endif; ?>
		<div class="clear"></div>
		<!-- banner -->
		<div class="archive-banner" align="center">
				<?php if(get_option('tgpwp_page_ad')) { ?>
				<?php echo get_option('tgpwp_page_ad'); ?>
				<?php } else { ?>
				<a href="http://tgpwp.com"><img src="<?php bloginfo('template_url'); ?>/images/gallery-banner.gif" alt="Get this WordPress theme for free here!" /></a>
				<?php } ?>
		</div><!-- /banner -->
		</div><!-- /content -->
</div><!-- /content area -->
<?php include (TEMPLATEPATH . '/includes/single-footer-widget.php'); ?>
<?php get_footer(); ?>