<?php
/*TGPWP V2.8*/
 global $shortname, $css_style_path;
?>
<!-- Single Post Footer Widgets -->
<div class="widgetspace">
<div class="widgetarea">
			<ul>
				<?php	if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Gallery Footer') ) : ?>
				
				<li class="widgetbox">
					<h2 class="widget-title">Categories</h2>
					<ul id="widget_categories"><?php wp_list_categories('show_count=1&title_li='); ?></ul>
				</li>
				
				<li class="widgetbox">
					<h2 class="widget-title">Sponsor Banner</h2>
					<div class="footeradwrap">
					<a href="http://tgpwp.com"><img src="<?php bloginfo('template_url'); ?>/images/footer-ad.jpg" alt="Get this theme for free now!" /></a>
					</div>
				</li>
				
				<li class="widgetbox">
					<h2 class="widget-title">Top Links</h2>
					<ul>
					<?php wp_list_bookmarks('title_li=&categorize=0'); ?>
					</ul>
				</li>
								
				<?php endif; ?>
			</ul>
</div><!-- /widgetarea -->
</div><!-- /widgetspace -->
<!-- /Single Post Footer Widgets -->