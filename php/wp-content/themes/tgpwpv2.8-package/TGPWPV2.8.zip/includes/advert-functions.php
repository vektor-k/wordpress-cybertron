<?php 

/* Meta boxes These are added to post area when creating a post. Nothing to edit here my friend. */

function admin_init(){
	add_meta_box("et_post_meta", "TGPWP Advertising Custom Fields", "et_post_meta", "post", "normal", "high");
}
add_action("admin_init", "admin_init");

function et_post_meta($callback_args) {
	global $post;
	
	$post_type = $callback_args->post_type;
	$temp_array = array();

	$temp_array = maybe_unserialize(get_post_meta($post->ID,'et_event_settings',true));

	$text = isset( $temp_array['text'] ) ? $temp_array['text'] : '';
	$tlink = isset( $temp_array['tlink'] ) ? $temp_array['tlink'] : '';
	$banner = isset( $temp_array['banner'] ) ? $temp_array['banner'] : '';
	$link = isset( $temp_array['link'] ) ? $temp_array['link'] : '';
	$mobitext = isset( $temp_array['mobitext'] ) ? $temp_array['mobitext'] : '';
	$mobitlink = isset( $temp_array['mobitlink'] ) ? $temp_array['mobitlink'] : '';
	$mobibanner = isset( $temp_array['mobibanner'] ) ? $temp_array['mobibanner'] : '';
	$mobilink = isset( $temp_array['mobilink'] ) ? $temp_array['mobilink'] : '';
	?>
	
		<div id="et_custom_settings" style="margin: 13px 0 17px 4px;">				
		<div id="et_settings_featured_options" style="margin-top: 12px;">		
			<div class="et_fs_setting" style="margin: 13px 0 26px 4px;">
				<label for="text" style="color: #000; font-weight: bold;"> Top Text: </label>
				<input type="text" class="small-text" value="<?php echo $text; ?>" id="text" name="text" style="width: 500px; border: 1px solid #66AEF3;" />
				<br />
				<small style="position: relative; top: 8px;">ex: <code>Click Here For More..</code></small>
			</div>
			
			<div class="et_fs_setting" style="margin: 13px 0 26px 4px;">
				<label for="tlink" style="color: #000; font-weight: bold;"> Text Link: </label>
				<input type="text" class="small-text" value="<?php echo $tlink; ?>" id="tlink" name="tlink" style="width: 500px; border: 1px solid #66AEF3;" />
				<br />
				<small style="position: relative; top: 8px;">ex: <code>http://AffiliateLink.com</code></small>
			</div>
			
			<div class="et_fs_setting" style="margin: 13px 0 26px 4px;">
				<label for="banner" style="color: #000; font-weight: bold;"> Bottom Banner URL: </label>
				<input type="text" class="small-text" value="<?php echo $banner; ?>" id="banner" name="banner" style="width: 500px; border: 1px solid #66AEF3;" />
				<br />
				<small style="position: relative; top: 8px;">ex: <code>Full Path To Your Banner</code></small>
			</div>
			
			<div class="et_fs_setting" style="margin: 13px 0 26px 4px;">
				<label for="link" style="color: #000; font-weight: bold;"> Banner Link: </label>
				<input type="text" class="small-text" value="<?php echo $link; ?>" id="link" name="link" style="width: 500px; border: 1px solid #66AEF3;" />
				<br />
				<small style="position: relative; top: 8px;">ex: <code>http://AffiliateLink.com</code></small>
			</div>
			
			<h2>Advertising elements for mobile theme.</h2>
			
			<div class="et_fs_setting" style="margin: 13px 0 26px 4px;">
				<label for="mobitext" style="color: #000; font-weight: bold;"> Text For Mobile: </label>
				<input type="text" class="small-text" value="<?php echo $mobitext; ?>" id="mobitext" name="mobitext" style="width: 500px; border: 1px solid #66AEF3;" />
				<br />
				<small style="position: relative; top: 8px;">ex: <code>Click Here For More..</code> Keep it short!</small>
			</div>
			
			<div class="et_fs_setting" style="margin: 13px 0 26px 4px;">
				<label for="mobitlink" style="color: #000; font-weight: bold;"> Link For Mobile: </label>
				<input type="text" class="small-text" value="<?php echo $mobitlink; ?>" id="mobitlink" name="mobitlink" style="width: 500px; border: 1px solid #66AEF3;" />
				<br />
				<small style="position: relative; top: 8px;">ex: <code>http://AffiliateLink.com</code></small>
			</div>
			
			<div class="et_fs_setting" style="margin: 13px 0 26px 4px;">
				<label for="mobibanner" style="color: #000; font-weight: bold;"> Mobile Banner: </label>
				<input type="text" class="small-text" value="<?php echo $mobibanner; ?>" id="mobibanner" name="mobibanner" style="width: 500px; border: 1px solid #66AEF3;" />
				<br />
				<small style="position: relative; top: 8px;">Important: <code>320px x 80px Max!</code></small>
			</div>
			
			<div class="et_fs_setting" style="margin: 13px 0 26px 4px;">
				<label for="mobilink" style="color: #000; font-weight: bold;"> Link for mobile banner: </label>
				<input type="text" class="small-text" value="<?php echo $mobilink; ?>" id="mobilink" name="mobilink" style="width: 500px; border: 1px solid #66AEF3;" />
				<br />
				<small style="position: relative; top: 8px;">ex: <code>http://AffiliateLink.com</code></small>
			</div>
		</div> <!-- #et_settings_featured_options -->
	</div> <!-- #et_custom_settings -->
		
	<?php
}

add_action('save_post', 'save_details');
function save_details($post_id){
	global $post;
	
	$temp_array = array();
		
	if ( defined('DOING_AUTOSAVE') && DOING_AUTOSAVE ) 
		return $post_id;
			
	$temp_array['text'] = isset($_POST["text"]) ? $_POST["text"] : '';
	$temp_array['tlink'] = isset($_POST["tlink"]) ? $_POST["tlink"] : '';
	$temp_array['banner'] = isset($_POST["banner"]) ? $_POST["banner"] : '';
	$temp_array['link'] = isset($_POST["link"]) ? $_POST["link"] : '';
	$temp_array['mobitext'] = isset($_POST["text"]) ? $_POST["mobitext"] : '';
	$temp_array['mobitlink'] = isset($_POST["tlink"]) ? $_POST["mobitlink"] : '';
	$temp_array['mobibanner'] = isset($_POST["mobibanner"]) ? $_POST["mobibanner"] : '';
	$temp_array['mobilink'] = isset($_POST["mobilink"]) ? $_POST["mobilink"] : '';
			
	update_post_meta( $post->ID, "et_event_settings", $temp_array );
}

?>