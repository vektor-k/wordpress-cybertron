<div id="featured-post">
					<div class="gallery-title">
				<?php if(get_option('tgpwp_featured_topper')) { ?>
				<h3><?php echo get_option('tgpwp_featured_topper'); ?></h3>
				<?php } else { ?>
				<h3>Check out these featured galleries</h3>
				<?php } ?>
			</div>
				<!-- post -->
				<?php
//get post type ==> featured
	global $post;
	$args = array(
		'post_type' =>'featured',
		'numberposts' => '4'
	);
	$featured_posts = get_posts($args);
?>
<?php if($featured_posts) { ?>        
	<?php
	$count=0;
	foreach($featured_posts as $post) : setup_postdata($post);
	$count++;
	//get featured thumbnail
	$thumbail = wp_get_attachment_image_src(get_post_thumbnail_id(), 'thumb');
	?>
    
    <?php if ( has_post_thumbnail() ) {  ?>
    <div class="home-post-wrap">
    <?php if (get_option('tgpwp_thumbnail_title') == "true") { ?>
				<div class="posttitle"><a href="<?php the_permalink() ?>"><?php short_title('...', '20'); ?></a></div>
				<?php } ?>
    	<div class="thumbnail-div">
    		<?php if(get_post_meta($post->ID, "tgpwp_redirect", true)) { ?>
    		<?php get_post_meta($post->ID, "tgpwp_redirect_url"); ?>
				<a href="<?php echo get_post_meta($post->ID, "tgpwp_redirect_url", true); ?>" title="<?php the_title(); ?>" target="_blank"><img src="<?php echo $thumbail[0]; ?>" height="<?php echo $thumbail[2]; ?>" width="<?php echo $thumbail[1]; ?>" alt="<?php echo the_title(); ?>" /></a>
				<?php } else { ?>
				<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><img src="<?php echo $thumbail[0]; ?>" height="<?php echo $thumbail[2]; ?>" width="<?php echo $thumbail[1]; ?>" alt="<?php echo the_title(); ?>" /></a>
				<?php } ?>
  	</div>
  	<div class="infobox">
				<div class="ratingbox"><!-- ratingbox -->
				<?php if(function_exists('the_ratings')) { the_ratings(); } ?>
			</div><!-- /ratingbox -->
			<div class="viewbox">
			<?php if(function_exists('the_views')) {  ?><p class="views"><?php the_views(); ?></p><?php } ?>
			</div>
		</div>
    </div>
    <?php } ?>
    
    <?php
	if($count == '4') { echo '<div class="clear"></div>'; $count=0; }
    endforeach; ?>

</div>
<!-- END #home-projects -->      	
<?php } ?>
<div class="clear"></div>