<?php
/**TGPWP V2.5**/
get_header();
?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
					<div id="single-gallery">
					<!-- post -->
					<div <?php post_class('post') ?> id="post-<?php the_ID(); ?>">
						<h3><?php the_title(); ?></h3>
						<!-- Single Text Code -->
								<div id="tlink">
								<?php get_post_meta($post->ID, "tgpwp_textlink") || get_post_meta($post->ID, "tgpwp_textlink_url") ?>
								<a href="<?php echo get_post_meta($post->ID, "tgpwp_textlink_url", true); ?>"><?php echo get_post_meta($post->ID, "tgpwp_textlink", true); ?></a>
								</div><!-- /Single Text Code -->
						<div class="entry">
							<?php the_content('Read the rest of this entry &raquo;'); ?>
							<!-- Single Banner Code -->
								<div class="single-banner" align="center">
								<?php get_post_meta($post->ID, "tgpwp_banner") || get_post_meta($post->ID, "tgpwp_banner_url") ?>
								<a href="<?php echo get_post_meta($post->ID, "tgpwp_banner_url", true); ?>"><img src="<?php echo get_post_meta($post->ID, "tgpwp_banner", true); ?>" alt=""></a>
								</div><!-- /Single Banner Code -->
						<div class="postmeta">
							<div class="tagbox">Added On: <?php the_date() ?></div>
							<div class="ratingbox-featured"><?php if(function_exists('the_ratings')) { the_ratings(); } ?></div>
						<div class="clear"></div>
						</div>
					</div>
					<!-- /post -->
</div><!-- /post -->
</div><!-- /single-gallery -->
<?php endwhile; ?>
<?php endif; ?>
	<?php get_sidebar(); ?>
	</div><!-- /content_body -->
<?php include (TEMPLATEPATH . '/includes/single-footer-widget.php'); ?>
<?php get_footer(); ?>