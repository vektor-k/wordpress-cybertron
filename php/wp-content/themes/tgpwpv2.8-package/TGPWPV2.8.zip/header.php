<?php
/**TGP WP V2.8**/
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<?php if(get_option('tgpwp_color_scheme')) { ?>
<style media="screen,projection" type="text/css">@import "<?php bloginfo('template_url'); ?>/themes/<?php echo get_option('tgpwp_color_scheme'); ?>/styles.css"</style>
<?php } ?>
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<!--[if lte IE 7]><style media="screen,projection" type="text/css">@import "<?php bloginfo('template_url'); ?>/style-ie.css";</style><![endif]-->
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
	<div id="topbar">
		<h2><?php bloginfo('description'); ?></h2>
	</div>
<!-- wrapper -->
<div class="wrapper">
	<!-- header -->
	<div id="header" style="background:<?php echo get_option('tgpwp_header_bg'); ?>;">
		<!-- header-area -->
		<div class="header-area">
		<!-- header_logo -->
		<?php (get_option('tgpwp_logo_padding')); ?>
		<div id="header-logo" style="padding:<?php echo get_option('tgpwp_logo_padding'); ?>;">
			<?php if(get_option('tgpwp_logo')) { ?>
				<a href="<?php echo home_url(); ?>"><img src="<?php echo get_option('tgpwp_logo'); ?>" alt="<?php bloginfo( 'name' ); ?>" /></a>
				<?php } else { ?>
				<h1><a href="<?php echo home_url(); ?>"><?php bloginfo( 'name' ); ?></a></h1>
				<?php } ?>
		</div><!-- /header_logo -->
		<!-- header_banner -->
		<div id="header-banner" style="padding:<?php echo get_option('tgpwp_banner_padding'); ?>;">
				<?php if(get_option('tgpwp_header_ad')) { ?>
				<?php echo get_option('tgpwp_header_ad'); ?>
				<?php } else { ?>
				<a href="http://tgpwp.com"><img src="<?php bloginfo('template_url'); ?>/images/header-banner.gif" alt="Get this WordPress theme for free here!" /></a>
				<?php } ?>
		</div><!-- /header_banner -->
		</div><!-- /header-area -->
	</div><!-- /header -->
	<!-- menu -->
	<div id="menu">
	<?php 
	  wp_nav_menu( array(
		'theme_location' => 'main-menu', // Setting up the location for the main-menu, Main Navigation.
		'menu_class' => 'sf-menu', //Adding the class for dropdowns
		'container_id' => 'navwrap', //Add CSS ID to the containter that wraps the menu.
		'fallback_cb' => 'wp_page_menu', //if wp_nav_menu is unavailable, Wordpress displays wp_page_menu function, which displays the pages of your blog. 
		// 'walker'	=>	new my_custom_walker(),
			)
		);
	?>
	</div><!-- /menu -->
			<!-- Content Area -->
			<div id="content-area">